from setuptools import setup, find_packages

setup(
  name="manish_calculator",
  version="0.1.0",
  author="Your Name",
  author_email="your_email@example.com",
  description="A simple calculator package",
  packages=find_packages(),
  install_requires=[],
)
